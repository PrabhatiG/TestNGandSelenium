package Activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity6 {
	WebDriver driver;
	WebDriverWait wait;
	
	 @BeforeClass
	  public void beforeClass() {
		 driver=new ChromeDriver();
		 wait=new WebDriverWait(driver,10);
		 //Open the browser
		 driver.get("https://alchemy.hguy.co/lms");
	  }

   @Test
  public void TestCase6() throws InterruptedException {
	 //Find my account in navigation bar and click it
		  driver.findElement(By.xpath("//*[@id=\"menu-item-1507\"]/a")).click();
		  
		  Thread.sleep(5000L);
		  
		  //Get the title of My account page:
		  String titleText=driver.getTitle();
		  System.out.println(titleText);
		  Assert.assertEquals(titleText, "My Account � Alchemy LMS");
		  
		  //Click on Login link:
		  driver.findElement(By.xpath("//*[@id=\"uagb-column-e9d225cb-cee9-4e02-a12d-073d5f051e91\"]/div[2]/div[2]/a")).click();
		  
		  
		  Thread.sleep(5000L);
		 
		  //Find username and Password field
		  
		  WebElement userNameField=driver.findElement(By.id("user_login"));
		  WebElement passwordField=driver.findElement(By.id("user_pass"));
		  
		  //Enter the values in username and password field:
		  
		  userNameField.sendKeys("root");
		  passwordField.sendKeys("pa$$w0rd");
		  
		  //Click on Login button:
		  driver.findElement(By.id("wp-submit")).click();
		  
		  Thread.sleep(5000L);
		  String titleText1=driver.getTitle();
		  System.out.println(titleText1);
		  
		  WebElement loggedinUser=driver.findElement(By.xpath("//*[@id=\"wp-admin-bar-my-account\"]/a/span"));
		  String loggedinUserName= loggedinUser.getText();
		  System.out.println(loggedinUserName);
		  Assert.assertEquals(loggedinUserName, "root");
   }
  
 
              @AfterClass
             public void afterClass() {
	         //Close the browser:
	          driver.quit();
	  
  }

}
