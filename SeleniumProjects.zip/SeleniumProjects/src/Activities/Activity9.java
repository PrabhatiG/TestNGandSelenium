package Activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class Activity9 {
	WebDriver driver;
	WebDriverWait wait;
	
	
  @BeforeClass
  public void beforeClass() {
	  driver=new ChromeDriver();
	  wait=new WebDriverWait(driver,10);
	  
	  //Open the browser
	  driver.get("https://alchemy.hguy.co/lms");
	  
	  //maximise the window
	  driver.manage().window().maximize();
	  
	  }
	
	@Test
     public void TestCase9() throws InterruptedException {
		//*[@id="uagb-column-e9d225cb-cee9-4e02-a12d-073d5f051e91"]/div[2]/div[2]/a
		
		driver.findElement(By.xpath("//*[@id=\"menu-item-1507\"]/a")).click();
		
		//Click on Login link:
		driver.findElement(By.xpath("//*[@id=\"uagb-column-e9d225cb-cee9-4e02-a12d-073d5f051e91\"]/div[2]/div[2]/a")).click();
		
		
		//Find username and Password field
		  
		  WebElement userNameField=driver.findElement(By.id("user_login"));
		  WebElement passwordField=driver.findElement(By.id("user_pass"));
		
		//Enter the values in username and password field:
		  
		  userNameField.sendKeys("root");
		  passwordField.sendKeys("pa$$w0rd");
		  
		  //Click on Login button:
		  driver.findElement(By.id("wp-submit")).click();
		  
		
		//Click "All Courses" link in navigation bar
		driver.findElement(By.xpath("//*[@id=\"menu-item-1508\"]/a")).click();
		
		//Select any course and open it:
		driver.findElement(By.xpath("//a[@role='button']")).click();
		
		//Click on a lesson in the course. Verify the title of the course.
		driver.findElement(By.xpath("//div[@class='ld-item-title']")).click();
		
		Thread.sleep(5000L);
		// Get title of the page
		String titleText=driver.getTitle();
		System.out.println(titleText);
		
		driver.findElement(By.xpath("//*[@id=\"learndash_post_83\"]/div/div[1]/div/div[2]")).click();
		Thread.sleep(5000L);
		
	}
  

  @AfterClass
  public void afterClass() {
	  //Close the browser
	  driver.quit();
  }

}
