package Activities;

import org.testng.annotations.Test;

import junit.framework.Assert;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;



public class Activity2 {
	WebDriver driver;
	WebDriverWait wait;
	
	 @BeforeClass
	  public void beforeClass() {
		 driver=new ChromeDriver();
		 wait=new WebDriverWait(driver, 10);
		 
		 //open the browser
		 driver.get("https://alchemy.hguy.co/lms");
		  }

	
    @Test
    public void TestCase2() {
    	
    	//Get heading of webpage
    	
    WebElement Heading=	driver.findElement(By.xpath("//*[@id=\"uagb-infobox-74cd79b6-b855-4e72-81bc-e70591de1896\"]/div/div/div/div[1]/h1"));
    
    String HeadingText=Heading.getText();
    System.out.println(HeadingText);
    Assert.assertEquals(HeadingText,"Learn from Industry Experts" );
    	
    }
 
  @AfterClass
  public void afterClass() {
	  //Close the browser
	  driver.close();
  }

}
