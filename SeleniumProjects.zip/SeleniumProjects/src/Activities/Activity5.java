package Activities;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class Activity5 {
	WebDriver driver;
	WebDriverWait wait;
	
	 @BeforeTest
	  public void beforeTest() {
		 
		 driver=new ChromeDriver();
		 wait=new WebDriverWait(driver,10);
		 
		 //Open the browser
		 driver.get("https://alchemy.hguy.co/lms");
	  }

	
  @Test
  public void TestCase5() throws InterruptedException {
	  //Find my account in navigation bar and click it
	  driver.findElement(By.xpath("//*[@id=\"menu-item-1507\"]/a")).click();
	  Thread.sleep(5000L);
	  //Get the title of My account page:
	  String titleText=driver.getTitle();
	  System.out.println(titleText);
	 
	  Assert.assertEquals(titleText, "My Account � Alchemy LMS");
	  
  }
 
  @AfterTest
  public void afterTest() {
	  //Close the browser
	  driver.quit();
  }

}
