package Activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity1 {
	 WebDriver driver;
	 WebDriverWait wait;
	
@BeforeClass
  public void beforeClass() {
	
	driver=new ChromeDriver();
	wait=new WebDriverWait(driver,10);
	//Open the Browser
	driver.get("https://alchemy.hguy.co/lms");
	 }


  @Test
  public void TestCase1() {
	  //Get title of website
	 String title =driver.getTitle();
	 //Print title of page
	 System.out.println(title);
	 Assert.assertEquals(title,  "Alchemy LMS � An LMS Application");
  }
  
  @AfterClass
  public void afterClass() {
	  //Close the browser
	  driver.close();
	  
  }

}
