package Activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Activity7 {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@BeforeTest
	  public void beforeTest() {
		driver=new ChromeDriver();
		wait=new WebDriverWait(driver,10);
		
		//Open the browser
		driver.get("https://alchemy.hguy.co/lms/");
		
	  }
	
  @Test
  public void TestCase7() {
	  //Click on all courses link
	  
	  driver.findElement(By.id("menu-item-1508")).click();
	  
	  //Find the number of courses 
	  
	  List<WebElement>courses= driver.findElements(By.className("entry-title"));
	  int coursesnum=courses.size();
	  
	  //Print the number of courses
	  System.out.println("Number of courses are:" +coursesnum);
	  
  }
  
  @AfterTest
  public void afterTest() {
	  //Close the browser
	  driver.quit();
  }

}
